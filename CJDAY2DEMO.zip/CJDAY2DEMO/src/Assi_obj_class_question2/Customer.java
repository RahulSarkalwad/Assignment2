package Assi_obj_class_question2;

public class Customer {
int custid;
String Custname;
String custcity;
String custname;
public Customer()
{
}	
          public int getcustid()
        {
	      return custid;
        }
          public void setcustid(int custid)
        {
          this.custid=custid;
        }
          
          public String getcustname()
          {
  	      return custname;
          }
            public void setcustname(String custid)
          {
            this.custname=custname;
          }
            
            public String getcustcity()
            {
    	      return custcity;
            }
              public void setcustcity(String custcity)
            {
              this.custcity=custcity;
            }

void print()
{
	System.out.println(custid+"\t"+custname+"\t"+custcity);
}




}



	


