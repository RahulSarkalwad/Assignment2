package Assi_obj_class_question2;

public class Customermain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Customer c1=new Customer();
c1.custid=100;
c1.custname="rahul";
c1.custcity="Nanded";
c1.print();
//c1.setcustname("Dharth");
c1.print();	
	}

}
