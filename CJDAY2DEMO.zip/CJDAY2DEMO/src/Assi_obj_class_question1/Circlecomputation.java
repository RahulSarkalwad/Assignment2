package Assi_obj_class_question1;

import java.util.Scanner;

public class Circlecomputation 
{
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.print("Enter the radius ");
		double r=scanner.nextDouble();
		double a=calculateArea(r);
		double c=calculateCircumference(r);
		System.out.println("Area of the circle is: "+a);
		System.out.println("Circumference of the circle is: "+c);
	}
	     public static double calculateArea(double r) 
	     {
	    	 return 3.14*r*r;
	     }
	     public static double calculateCircumference(double r) 
	     {
	    	 return 3.14*2*r;
	     }
	
	}


