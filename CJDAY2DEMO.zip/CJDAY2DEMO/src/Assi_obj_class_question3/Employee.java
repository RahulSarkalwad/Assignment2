package Assi_obj_class_question3;

public class Employee 
{
	String name;
	int code;
	int hourswork;
	int wageperhour;
	
	public Employee()
	{
		name="Dharth";
		code=100;
		hourswork=8;
		wageperhour=100;
	}
	
	public String getname()
    {
      return name;
    }
      public void setname(String name)
    {
      this.name=name;
    }
      
      public int getcode()
      {
        return code;
      }
        public void setcode(int code)
      {
        this.code=code;
      }
        
        public int gethourswork()
        {
          return hourswork;
        }
          public void sethourswork(int hourswork)
        {
          this.hourswork=hourswork;
        }
          
          public int getwageperhour()
          {
            return wageperhour;
          }
            public void setwageperhour(int wageperhour)
          {
            this.wageperhour=wageperhour;
          }
            void print()
            {
            	System.out.println(name+"\t"+code+"\t"+hourswork+"\t"+wageperhour);
            }
	
	
	
	
	
}
	


