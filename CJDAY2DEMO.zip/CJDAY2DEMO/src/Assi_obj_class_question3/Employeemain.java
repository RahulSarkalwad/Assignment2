package Assi_obj_class_question3;

public class Employeemain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Employee e1=new Employee();
     int wage,wage1;
     wage=e1.hourswork*e1.wageperhour;
     
		System.out.println("Employee "+ e1.name+" earned "+wage);	
	}
	
	
	

}
